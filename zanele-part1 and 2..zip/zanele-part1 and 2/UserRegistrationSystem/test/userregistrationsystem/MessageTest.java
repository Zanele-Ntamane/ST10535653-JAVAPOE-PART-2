package userregistrationsystem;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MessageTest {

    // Test data from the brief
    private static final String ID_1 = "0012345678";
    private static final String CELL_1 = "+27718693002";
    private static final String MSG_1 = "Hi Hamiday, can you join us for salah tonight?";

    private static final String ID_2 = "1198765432";
    private static final String CELL_2 = "08575975889";
    private static final String MSG_2 = "Hi Amina, did you receive the abaya?";

    @BeforeEach
    void setUp() {
        Message.resetMessages();
    }

    @Test
    void messageLengthSuccess() {
        assertEquals("Message ready to send.", Message.checkMessageLength(MSG_1));
    }

    @Test
    void messageLengthFailure() {
        String longMessage = "a".repeat(260);
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.",
                Message.checkMessageLength(longMessage));
    }

    @Test
    void recipientNumberSuccess() {
        assertEquals("Cell phone number successfully captured.", Message.checkRecipientCell(CELL_1));
    }

    @Test
    void recipientNumberFailure() {
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                Message.checkRecipientCell(CELL_2));
    }

    @Test
    void messageHashTestCase1() {
        Message m = new Message(ID_1, 0, CELL_1, MSG_1);
        assertEquals("00:0:HITONIGHT", m.createMessageHash());
    }

    @Test
    void messageHashRemainingMessagesInLoop() {
        String[] ids = {ID_1, ID_2};
        String[] msgs = {MSG_1, MSG_2};
        String[] expected = {"00:0:HITONIGHT", "11:1:HIPAYMENT"};
        for (int i = 0; i < msgs.length; i++) {
            Message m = new Message(ids[i], i, CELL_1, msgs[i]);
            assertEquals(expected[i], m.createMessageHash());
        }
    }

    @Test
    void messageIdIsCreated() {
        String id = Message.generateMessageID();
        Message m = new Message(id, 0, CELL_1, MSG_1);
        assertEquals("Message ID generated: " + id, m.displayMessageID());
        assertEquals(10, id.length());
        assertTrue(m.checkMessageID());
    }

    @Test
    void messageIdTooLongFails() {
        Message m = new Message("12345678901", 0, CELL_1, MSG_1);
        assertFalse(m.checkMessageID());
    }

    @Test
    void sendMessage() {
        Message m = new Message(ID_1, 0, CELL_1, MSG_1);
        assertEquals("Message successfully sent.", m.SentMessage(1));
    }

    @Test
    void disregardMessage() {
        Message m = new Message(ID_2, 1, CELL_2, MSG_2);
        assertEquals("Press 0 to delete the message.", m.SentMessage(2));
    }

    @Test
    void storeMessage() {
        Message m = new Message(ID_1, 0, CELL_1, MSG_1);
        assertEquals("Message successfully stored.", m.SentMessage(3));
    }

    @Test
    void totalMessagesSent() {
        new Message(ID_1, 0, CELL_1, MSG_1).SentMessage(1);   // sent
        new Message(ID_2, 1, CELL_2, MSG_2).SentMessage(2);   // discarded
        assertEquals(1, Message.returnTotalMessages());
    }
}